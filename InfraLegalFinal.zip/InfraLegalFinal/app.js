// ================================================
// InfraLegal Pereira - Main App Vue.js
// ================================================

const { createApp, ref, computed, watch, onMounted, nextTick } = Vue;

const app = createApp({
    setup() {
        // ============================
        // Estado de Autenticación
        // ============================
        const isAuthenticated = ref(false);
        const loading = ref(false);
        const authMode = ref('login');
        const authError = ref('');
        const authSuccess = ref('');
        const currentUser = ref(null);

        const loginData = ref({
            email: '',
            password: ''
        });

        const registerData = ref({
            nombre: '',
            cedula: '',
            telefono: '',
            email: '',
            password: ''
        });

        // ============================
        // Vistas de la App
        // ============================
        const currentView = ref('comparendos');

        // ============================
        // Comparendos
        // ============================
        const comparendoNum = ref('');
        const comparendoResult = ref(null);
        const comparendoError = ref('');
        const loadingComparendo = ref(false);

        // ============================
        // Chat con Abogado
        // ============================
        const chatMessages = ref([]);
        const chatInput = ref('');
        const chatContainer = ref(null);

        // ============================
        // Chatbot
        // ============================
        const chatbotMessages = ref([]);
        const chatbotInput = ref('');
        const chatbotContainer = ref(null);

        const quickQuestions = [
            'multas',
            'plazos',
            'apelar',
            'SOAT',
            'licencia'
        ];

        // ============================
        // Historial
        // ============================
        const historialConversaciones = ref([]);
        const loadingHistorial = ref(false);

        // ============================
        // Estado del Caso
        // ============================
        const casoId = ref('');
        const casoActual = ref(null);
        const casoError = ref('');
        const loadingCaso = ref(false);
        const misCasos = ref([]);

        // ============================
        // Funciones de Autenticación
        // ============================

        async function register() {
            authError.value = '';
            authSuccess.value = '';
            loading.value = true;

            try {
                const firebaseUser = typeof window.registerUser === 'function'
                    ? await window.registerUser(
                        registerData.value.email,
                        registerData.value.password,
                        {
                            nombre: registerData.value.nombre,
                            cedula: registerData.value.cedula,
                            telefono: registerData.value.telefono,
                            email: registerData.value.email
                        })
                    : null;

                if (firebaseUser) {
                    authSuccess.value = '¡Registro exitoso! Bienvenido.';
                    setTimeout(() => {
                        isAuthenticated.value = true;
                        currentUser.value = firebaseUser;
                    }, 1500);
                } else {
                    await simulateDelay(1500);
                    authSuccess.value = '¡Registro exitoso! Puedes iniciar sesión.';
                    authMode.value = 'login';
                }
            } catch (error) {
                authError.value = error.message || 'Error en el registro';
            } finally {
                loading.value = false;
            }
        }

        async function login() {
            authError.value = '';
            loading.value = true;

            try {
                const firebaseUser = typeof window.loginUser === 'function'
                    ? await window.loginUser(loginData.value.email, loginData.value.password)
                    : null;

                if (firebaseUser) {
                    currentUser.value = firebaseUser;
                    isAuthenticated.value = true;
                } else {
                    await simulateDelay(1000);
                    if (loginData.value.email && loginData.value.password.length >= 6) {
                        currentUser.value = {
                            uid: 'user_' + Date.now(),
                            email: loginData.value.email
                        };
                        isAuthenticated.value = true;
                    } else {
                        throw new Error('Correo o contraseña inválidos (mínimo 6 caracteres)');
                    }
                }
            } catch (error) {
                authError.value = error.message || 'Error al iniciar sesión';
            } finally {
                loading.value = false;
            }
        }

        async function logout() {
            try {
                if (typeof window.logoutUser === 'function') {
                    await window.logoutUser();
                }
            } catch (error) {
                console.error('Error en logout:', error);
            }
            currentUser.value = null;
            isAuthenticated.value = false;
            resetViews();
        }

        // ============================
        // Funciones de Comparendos
        // ============================

        async function buscarComparendo() {
            comparendoError.value = '';
            comparendoResult.value = null;
            loadingComparendo.value = true;

            try {
                const numero = comparendoNum.value.trim();
                if (!numero) {
                    throw new Error('Ingresa el número de comparendo');
                }

                if (typeof window.API !== 'undefined' && window.API.buscarComparendoAPI) {
                    comparendoResult.value = await window.API.buscarComparendoAPI(numero);
                } else {
                    await simulateDelay(1500);
                    comparendoResult.value = {
                        numero: numero,
                        fecha: new Date().toLocaleDateString('es-CO'),
                        infraccion: 'Exceso de velocidad',
                        monto: 468000,
                        lugar: 'Carrera 7 # 12-35, Centro',
                        estado: 'Pendiente'
                    };
                }
            } catch (error) {
                comparendoError.value = error.message || 'Comparendo no encontrado';
            } finally {
                loadingComparendo.value = false;
            }
        }

        // ============================
        // Funciones de Chat
        // ============================

        function getChatTime() {
            return new Date().toLocaleTimeString('es-CO', {
                hour: '2-digit',
                minute: '2-digit'
            });
        }

        async function sendChatMessage() {
            const text = chatInput.value.trim();
            if (!text) return;

            chatMessages.value.push({
                id: Date.now(),
                sender: 'user',
                text: text,
                time: getChatTime()
            });

            chatInput.value = '';
            scrollToBottom(chatContainer);

            setTimeout(() => {
                const responses = [
                    "Entendido. ¿Podrías darme más detalles sobre tu situación?",
                    "Gracias por la información. Estoy revisando tu caso.",
                    "De acuerdo. ¿Tienes alguna prueba o testigo de lo sucedido?",
                    "Entiendo. Vamos a proceder con la asesoría legal.",
                    "Perfecto. Te estaré atendiendo en breve."
                ];

                chatMessages.value.push({
                    id: Date.now() + 1,
                    sender: 'abogado',
                    text: responses[Math.floor(Math.random() * responses.length)],
                    time: getChatTime()
                });

                scrollToBottom(chatContainer);
            }, 1500);
        }

        // ============================
        // Funciones de Chatbot
        // ============================

        async function sendToChatbot(message) {
            const text = message.trim();
            if (!text) return;

            chatbotMessages.value.push({
                sender: 'user',
                text: text,
                category: null,
                isHtml: false
            });

            chatbotInput.value = '';
            scrollToBottom(chatbotContainer);

            try {
                if (typeof window.CHATBOT !== 'undefined' && window.CHATBOT.generateResponse) {
                    const response = await window.CHATBOT.generateResponse(text);
                    chatbotMessages.value.push({
                        sender: 'bot',
                        text: response.text,
                        category: response.category,
                        isHtml: response.isHtml || false
                    });
                } else {
                    await simulateDelay(1000);
                    chatbotMessages.value.push({
                        sender: 'bot',
                        text: "Gracias por tu mensaje. ¿Podrías darme más detalles?",
                        category: 'general',
                        isHtml: false
                    });
                }
            } catch (error) {
                chatbotMessages.value.push({
                    sender: 'bot',
                    text: "Disculpa, tuve un problema. ¿Podrías repetir tu pregunta?",
                    category: 'error',
                    isHtml: false
                });
            }

            scrollToBottom(chatbotContainer);
        }

        // ============================
        // Funciones de Historial
        // ============================

        async function loadHistorial() {
            loadingHistorial.value = true;

            try {
                if (currentUser.value && typeof window.getHistorial === 'function') {
                    historialConversaciones.value = await window.getHistorial(currentUser.value.uid);
                } else {
                    await simulateDelay(500);
                    historialConversaciones.value = [
                        {
                            id: '1',
                            tipo: 'Chat con Abogado',
                            ultimoMensaje: 'Gracias por la asesoría',
                            fecha: '02/05/2026',
                            categoria: 'general',
                            mensajesCount: 12
                        },
                        {
                            id: '2',
                            tipo: 'Consulta Comparendo',
                            ultimoMensaje: 'Número: 123456',
                            fecha: '01/05/2026',
                            categoria: 'información',
                            mensajesCount: 4
                        },
                        {
                            id: '3',
                            tipo: 'Chatbot',
                            ultimoMensaje: '¿Cuál es el plazo para pagar?',
                            fecha: '28/04/2026',
                            categoria: 'plazos',
                            mensajesCount: 6
                        }
                    ];
                }
            } catch (error) {
                console.error('Error cargando historial:', error);
            } finally {
                loadingHistorial.value = false;
            }
        }

        function verConversacion(conv) {
            currentView.value = 'chat';
        }

        // ============================
        // Funciones de Estado de Caso
        // ============================

        async function buscarCaso() {
            casoError.value = '';
            casoActual.value = null;
            loadingCaso.value = true;

            try {
                const id = casoId.value.trim();
                if (!id) {
                    throw new Error('Ingresa el ID del caso');
                }

                if (typeof window.getCase === 'function') {
                    casoActual.value = await window.getCase(id);
                } else {
                    await simulateDelay(1000);
                    casoActual.value = {
                        id: id,
                        titulo: 'Apelación de Comparendo',
                        estado: 'proceso',
                        timeline: [
                            { label: 'Caso creado', fecha: '28/04/2026 10:30', completed: true },
                            { label: 'Asignado a abogado', fecha: '29/04/2026 09:15', completed: true },
                            { label: 'Revisión de documentos', fecha: '30/04/2026 14:20', completed: true },
                            { label: 'Preparación de apelación', fecha: 'En progreso', completed: false },
                            { label: 'Presentación ante autoridad', fecha: 'Pendiente', completed: false },
                            { label: 'Resolución', fecha: 'Pendiente', completed: false }
                        ],
                        ultimaActualizacion: '02/05/2026 14:20'
                    };
                }

                if (!casoActual.value) {
                    throw new Error('Caso no encontrado');
                }
            } catch (error) {
                casoError.value = error.message || 'Error al buscar caso';
            } finally {
                loadingCaso.value = false;
            }
        }

        async function loadMisCasos() {
            try {
                if (currentUser.value && typeof window.getUserCases === 'function') {
                    misCasos.value = await window.getUserCases(currentUser.value.uid);
                } else {
                    await simulateDelay(300);
                    misCasos.value = [
                        { id: 'CAS001', estado: 'proceso' },
                        { id: 'CAS002', estado: 'resuelto' },
                        { id: 'CAS003', estado: 'pendiente' }
                    ];
                }
            } catch (error) {
                console.error('Error cargando casos:', error);
            }
        }

        function verCaso(caso) {
            casoId.value = caso.id;
            buscarCaso();
        }

        // ============================
        // Utilidades
        // ============================

        async function simulateDelay(ms) {
            return new Promise(resolve => setTimeout(resolve, ms));
        }

        function scrollToBottom(refEl) {
            nextTick(() => {
                if (refEl && refEl.value) {
                    refEl.value.scrollTop = refEl.value.scrollHeight;
                }
            });
        }

        function resetViews() {
            currentView.value = 'comparendos';
            chatMessages.value = [];
            chatbotMessages.value = [];
            historialConversaciones.value = [];
            casoActual.value = null;
            comparendoResult.value = null;
        }

        function getCategoryClass(category) {
            const classes = {
                'urgente': 'bg-red-100 text-red-700',
                'apelación': 'bg-purple-100 text-purple-700',
                'plazos': 'bg-yellow-100 text-yellow-700',
                'información': 'bg-blue-100 text-blue-700',
                'general': 'bg-gray-100 text-gray-700'
            };
            return classes[category] || classes.general;
        }

        function getEstadoClass(estado) {
            const classes = {
                'pendiente': 'bg-yellow-500 text-white',
                'proceso': 'bg-blue-500 text-white',
                'resuelto': 'bg-green-500 text-white',
                'rechazado': 'bg-red-500 text-white'
            };
            return classes[estado] || 'bg-gray-500 text-white';
        }

        function getEstadoIcon(estado) {
            const icons = {
                'pendiente': 'fas fa-clock',
                'proceso': 'fas fa-spinner fa-spin',
                'resuelto': 'fas fa-check-circle',
                'rechazado': 'fas fa-times-circle'
            };
            return icons[estado] || 'fas fa-question-circle';
        }

        function getEstadoTextClass(estado) {
            const classes = {
                'pendiente': 'text-yellow-600',
                'proceso': 'text-blue-600',
                'resuelto': 'text-green-600',
                'rechazado': 'text-red-600'
            };
            return classes[estado] || 'text-gray-600';
        }

        function getEstadoDotColor(estado) {
            const colors = {
                'pendiente': 'bg-yellow-500',
                'proceso': 'bg-blue-500',
                'resuelto': 'bg-green-500',
                'rechazado': 'bg-red-500'
            };
            return colors[estado] || 'bg-gray-500';
        }

        // ============================
        // Watchers
        // ============================

        watch(currentView, (newView) => {
            if (newView === 'historial') {
                loadHistorial();
            } else if (newView === 'estado') {
                loadMisCasos();
            }
        });

        // ============================
        // Inicialización
        // ============================

        onMounted(() => {
            console.log('InfraLegal Pereira inicializado');
        });

        return {
            // Auth
            isAuthenticated,
            loading,
            authMode,
            authError,
            authSuccess,
            currentUser,
            loginData,
            registerData,
            register,
            login,
            logout,

            // Vista
            currentView,

            // Comparendos
            comparendoNum,
            comparendoResult,
            comparendoError,
            loadingComparendo,
            buscarComparendo,

            // Chat
            chatMessages,
            chatInput,
            chatContainer,
            sendChatMessage,

            // Chatbot
            chatbotMessages,
            chatbotInput,
            chatbotContainer,
            quickQuestions,
            sendToChatbot,

            // Historial
            historialConversaciones,
            loadingHistorial,
            verConversacion,

            // Estado Caso
            casoId,
            casoActual,
            casoError,
            loadingCaso,
            misCasos,
            buscarCaso,
            verCaso,

            // Utilidades
            getCategoryClass,
            getEstadoClass,
            getEstadoIcon,
            getEstadoTextClass,
            getEstadoDotColor
        };
    }
});

app.mount('#app');
console.log('Vue app montada correctamente');
