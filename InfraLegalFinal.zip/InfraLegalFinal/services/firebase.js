// ================================================
// Firebase Configuration - InfraLegal Pereira
// ================================================

// =====================================================
// IMPORTANTE: Reemplaza estas credenciales con las tuyas
// Crea un proyecto en https://console.firebase.google.com
// =====================================================

const firebaseConfig = {
    apiKey: "TU_API_KEY_AQUI",
    authDomain: "tu-proyecto.firebaseapp.com",
    projectId: "tu-proyecto",
    storageBucket: "tu-proyecto.appspot.com",
    messagingSenderId: "123456789",
    appId: "1:123456789:web:abc123"
};

// Inicializar Firebase
let auth, db;

function initFirebase() {
    // Verificar si las credenciales son placeholders
    if (firebaseConfig.apiKey === "TU_API_KEY_AQUI" || 
        firebaseConfig.apiKey === "" ||
        firebaseConfig.apiKey === "demo") {
        console.log('Modo simulación - Firebase no configurado');
        return;
    }
    
    try {
        // Inicializar Firebase App
        firebase.initializeApp(firebaseConfig);
        
        // Obtener servicios
        auth = firebase.auth();
        db = firebase.firestore();
        
        // Configurar Firestore para offline
        db.enablePersistence({ synchronizeTabs: true })
            .catch(err => {
                if (err.code === 'failed-precondition') {
                    console.warn('Firestore persistence failed: multiple tabs open');
                } else if (err.code === 'unimplemented') {
                    console.warn('Firestore persistence not available in this browser');
                }
            });
        
        console.log('Firebase initialized successfully');
    } catch (error) {
        console.error('Error initializing Firebase:', error);
    }
}

// ================================================
// Funciones de Autenticación
// ================================================

// Registrar nuevo usuario
async function registerUser(email, password, userData) {
    if (!auth) {
        return null; // Sin Firebase: app.js usará simulación
    }
    
    try {
        // Crear usuario en Auth
        const userCredential = await auth.createUserWithEmailAndPassword(email, password);
        const user = userCredential.user;
        
        // Guardar datos adicionales en Firestore
        await db.collection('usuarios').doc(user.uid).set({
            nombre: userData.nombre,
            cedula: userData.cedula,
            telefono: userData.telefono,
            email: userData.email,
            createdAt: firebase.firestore.FieldValue.serverTimestamp()
        });
        
        return user;
    } catch (error) {
        console.error('Error en registro:', error);
        throw formatAuthError(error.code);
    }
}

// Iniciar sesión
async function loginUser(email, password) {
    if (!auth) {
        return null; // Sin Firebase: app.js usará simulación
    }
    
    try {
        const userCredential = await auth.signInWithEmailAndPassword(email, password);
        return userCredential.user;
    } catch (error) {
        console.error('Error en login:', error);
        throw formatAuthError(error.code);
    }
}

// Cerrar sesión
async function logoutUser() {
    if (!auth) {
        return; // Sin Firebase: no hace nada, app.js maneja el estado
    }
    
    try {
        await auth.signOut();
    } catch (error) {
        console.error('Error en logout:', error);
        throw error;
    }
}

// Obtener usuario actual
function getCurrentUser() {
    return auth ? auth.currentUser : null;
}

// Observer de autenticación
function onAuthChange(callback) {
    if (!auth) {
        callback(null);
        return;
    }
    
    auth.onAuthStateChanged(callback);
}

// ================================================
// Funciones de Chat (Firestore Realtime)
// ================================================

// Enviar mensaje de chat
async function sendMessage(chatId, messageData) {
    if (!db) {
        throw new Error('Firestore no inicializado');
    }
    
    try {
        await db.collection('chats').doc(chatId).collection('mensajes').add({
            ...messageData,
            createdAt: firebase.firestore.FieldValue.serverTimestamp()
        });
        
        // Actualizar último mensaje del chat
        await db.collection('chats').doc(chatId).update({
            ultimoMensaje: messageData.text,
            updatedAt: firebase.firestore.FieldValue.serverTimestamp()
        });
    } catch (error) {
        console.error('Error enviando mensaje:', error);
        throw error;
    }
}

// Obtener mensajes en tiempo real (snapshot)
function subscribeToMessages(chatId, callback) {
    if (!db) {
        callback([]);
        return () => {};
    }
    
    return db.collection('chats')
        .doc(chatId)
        .collection('mensajes')
        .orderBy('createdAt', 'asc')
        .onSnapshot(snapshot => {
            const mensajes = [];
            snapshot.forEach(doc => {
                mensajes.push({ id: doc.id, ...doc.data() });
            });
            callback(mensajes);
        }, error => {
            console.error('Error en snapshot:', error);
            callback([]);
        });
}

// ================================================
// Funciones de Historial
// ================================================

// Guardar conversación en historial
async function saveToHistorial(userId, tipo, categoria, mensajes) {
    if (!db) {
        throw new Error('Firestore no inicializado');
    }
    
    try {
        await db.collection('historial').add({
            userId,
            tipo,
            categoria,
            mensajes: mensajes.slice(-20), // Últimos 20 mensajes
            ultimoMensaje: mensajes[mensajes.length - 1]?.text || '',
            mensajesCount: mensajes.length,
            fecha: firebase.firestore.FieldValue.serverTimestamp()
        });
    } catch (error) {
        console.error('Error guardando historial:', error);
        throw error;
    }
}

// Obtener historial del usuario
async function getHistorial(userId) {
    if (!db) {
        return [];
    }
    
    try {
        const snapshot = await db.collection('historial')
            .where('userId', '==', userId)
            .orderBy('fecha', 'desc')
            .get();
        
        return snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
    } catch (error) {
        console.error('Error obteniendo historial:', error);
        return [];
    }
}

// ================================================
// Funciones de Casos
// ================================================

// Crear nuevo caso
async function createCase(userId, casoData) {
    if (!db) {
        throw new Error('Firestore no inicializado');
    }
    
    try {
        const docRef = await db.collection('casos').add({
            userId,
            ...casoData,
            estado: 'pendiente',
            timeline: [{
                label: 'Caso creado',
                fecha: new Date().toLocaleString(),
                completed: true
            }],
            createdAt: firebase.firestore.FieldValue.serverTimestamp()
        });
        return docRef.id;
    } catch (error) {
        console.error('Error creando caso:', error);
        throw error;
    }
}

// Obtener caso por ID
async function getCase(casoId) {
    if (!db) {
        return null;
    }
    
    try {
        const doc = await db.collection('casos').doc(casoId).get();
        if (doc.exists) {
            return { id: doc.id, ...doc.data() };
        }
        return null;
    } catch (error) {
        console.error('Error obteniendo caso:', error);
        return null;
    }
}

// Obtener casos del usuario
async function getUserCases(userId) {
    if (!db) {
        return [];
    }
    
    try {
        const snapshot = await db.collection('casos')
            .where('userId', '==', userId)
            .orderBy('createdAt', 'desc')
            .get();
        
        return snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
    } catch (error) {
        console.error('Error obteniendo casos:', error);
        return [];
    }
}

// Actualizar estado del caso
async function updateCaseStatus(casoId, nuevoEstado, label) {
    if (!db) {
        throw new Error('Firestore no inicializado');
    }
    
    try {
        const caso = await getCase(casoId);
        if (!caso) {
            throw new Error('Caso no encontrado');
        }
        
        const newTimeline = [...caso.timeline, {
            label,
            fecha: new Date().toLocaleString(),
            completed: true
        }];
        
        await db.collection('casos').doc(casoId).update({
            estado: nuevoEstado,
            timeline: newTimeline,
            ultimaActualizacion: firebase.firestore.FieldValue.serverTimestamp()
        });
    } catch (error) {
        console.error('Error actualizando caso:', error);
        throw error;
    }
}

// ================================================
// Funciones de Usuarios
// ================================================

// Obtener datos del usuario
async function getUserData(userId) {
    if (!db) {
        return null;
    }
    
    try {
        const doc = await db.collection('usuarios').doc(userId).get();
        if (doc.exists) {
            return doc.data();
        }
        return null;
    } catch (error) {
        console.error('Error obteniendo datos de usuario:', error);
        return null;
    }
}

// Actualizar datos del usuario
async function updateUserData(userId, data) {
    if (!db) {
        throw new Error('Firestore no inicializado');
    }
    
    try {
        await db.collection('usuarios').doc(userId).update({
            ...data,
            updatedAt: firebase.firestore.FieldValue.serverTimestamp()
        });
    } catch (error) {
        console.error('Error actualizando datos de usuario:', error);
        throw error;
    }
}

// ================================================
// Utilidades
// ================================================

// Formatear errores de Firebase Auth
function formatAuthError(errorCode) {
    const errors = {
        'auth/email-already-in-use': 'Este correo ya está registrado',
        'auth/invalid-email': 'Correo electrónico inválido',
        'auth/operation-not-allowed': 'Operación no permitida',
        'auth/weak-password': 'La contraseña es muy débil',
        'auth/user-disabled': 'Usuario deshabilitado',
        'auth/user-not-found': 'Usuario no encontrado',
        'auth/wrong-password': 'Contraseña incorrecta',
        'auth/invalid-login-credentials': 'Credenciales inválidas',
        'auth/too-many-requests': 'Demasiados intentos. Intenta más tarde'
    };
    
    return errors[errorCode] || 'Error de autenticación';
}

// Inicializar Firebase al cargar
if (typeof firebase !== 'undefined') {
    initFirebase();
}