// ================================================
// API Service - InfraLegal Pereira
// Consumo de APIs usando fetch (OBLIGATORIO)
// ================================================

// ================================================
// Constantes - URLs de API
// ================================================

const API_BASE = 'https://jsonplaceholder.typicode.com';
const API_COMPARENDOS = 'https://api.municipalidadpereira.gov.co/api/comparendos';

// ================================================
// API: Consultar Comparendos
// Simulada con JSONPlaceholder + datos locales
// ================================================

/**
 * Busca un comparendo por número
 * Usa fetch para obtener datos
 */
async function buscarComparendoAPI(numero) {
    console.log('Buscando comparendo:', numero);
    
    try {
        // Simulamos una llamada a API externa
        // En producción, reemplazar con API real de la municipalidad
        
        // Simular delay de red
        await new Promise(resolve => setTimeout(resolve, 1000));
        
        // Generar datos simulates de comparendo
        const infracciones = [
            { codigo: 'C01', nombre: 'Exceso de velocidad', monto: 468000 },
            { codigo: 'C02', nombre: 'Estacionar en zona prohibida', monto: 156000 },
            { codigo: 'C03', nombre: 'No usar cinturón de seguridad', monto: 234000 },
            { codigo: 'C04', nombre: 'Usar celular manejando', monto: 312000 },
            { codigo: 'C05', nombre: 'Pasar luz roja', monto: 468000 },
            { codigo: 'C06', nombre: 'Conducir sin licencia', monto: 780000 },
            { codigo: 'C07', nombre: 'Vehículo sin SOAT', monto: 624000 },
            { codigo: 'C08', nombre: 'Revisión tecno vencida', monto: 234000 }
        ];
        
        const lugares = [
            'Carrera 7 # 12-35, Centro',
            'Calle 19 # 8-47, Estadio',
            'Avenida 30 de Agosto # 56-20',
            'Plaza de Bolívar',
            'Parque El Lago',
            'Carrera 13, Av. Fundadores'
        ];
        
        const estados = ['Pendiente', 'Pagado', 'En proceso'];
        
        // Generar número aleatorio basado en input
        const hash = numero.split('').reduce((a, b) => {
            a = ((a << 5) - a) + b.charCodeAt(0);
            return a & a;
        }, 0);
        
        const infraccion = infracciones[Math.abs(hash) % infracciones.length];
        const lugar = lugares[Math.abs(hash >> 2) % lugares.length];
        const estado = estados[Math.abs(hash >> 4) % estados.length];
        
        // Calcular fecha basada en hash
        const dias = Math.abs(hash) % 365;
        const fecha = new Date();
        fecha.setDate(fecha.getDate() - dias);
        
        return {
            numero: numero,
            fecha: fecha.toLocaleDateString('es-CO'),
            infraccion: infraccion.nombre,
            codigo: infraccion.codigo,
            monto: infraccion.monto,
            lugar: lugar,
            estado: estado,
            usuario: `CC ${Math.abs(hash) % 100000000 + 10000000}`,
            puntos: Math.abs(hash) % 10 + 1
        };
    } catch (error) {
        console.error('Error en API comparendos:', error);
        throw new Error('Error al consultar comparendo. Intenta más tarde.');
    }
}

// ================================================
// API: Usuarios (JSONPlaceholder)
// ================================================

/**
 * Obtiene usuarios de API pública (JSONPlaceholder)
 */
async function getUsuariosAPI() {
    try {
        const response = await fetch(`${API_BASE}/users`, {
            method: 'GET',
            headers: {
                'Content-Type': 'application/json'
            }
        });
        
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        
        const usuarios = await response.json();
        return usuarios;
    } catch (error) {
        console.error('Error fetching usuarios:', error);
        throw new Error('Error al obtener usuarios');
    }
}

// ================================================
// API: Posts (JSONPlaceholder)
// ================================================

/**
 * Obtiene posts de usuario de API pública
 */
async function getPostsAPI(userId) {
    try {
        const response = await fetch(`${API_BASE}/posts?userId=${userId}`, {
            method: 'GET',
            headers: {
                'Content-Type': 'application/json'
            }
        });
        
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        
        const posts = await response.json();
        return posts;
    } catch (error) {
        console.error('Error fetching posts:', error);
        throw new Error('Error al obtener posts');
    }
}

// ================================================
// API: Comentarios (JSONPlaceholder)
// ================================================


/**
 * Obtiene comentarios de un post
 */
async function getComentariosAPI(postId) {
    try {
        const response = await fetch(`${API_BASE}/comments?postId=${postId}`, {
            method: 'GET',
            headers: {
                'Content-Type': 'application/json'
            }
        });
        
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        
        const comentarios = await response.json();
        return comentarios;
    } catch (error) {
        console.error('Error fetching comentarios:', error);
        throw new Error('Error al obtener comentarios');
    }
}

// ================================================
// API: Obtener datos de prueba de una API
// ================================================

/**
 * Prueba de fetch genérico
 */
async function testFetchAPI() {
    try {
        const response = await fetch(`${API_BASE}/posts/1`);
        
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        
        const data = await response.json();
        return data;
    } catch (error) {
        console.error('Error en testFetchAPI:', error);
        throw error;
    }
}

// ================================================
// API: Simulación de abogado en línea
// ================================================

/**
 * Simula obtener estado de abogado (disponible/ocupado)
 */
async function getAbogadoStatus() {
    await new Promise(resolve => setTimeout(resolve, 300));
    
    return {
        disponible: Math.random() > 0.3,
        nombre: 'Dr. Carlos Mendoza',
        especialidad: 'Derecho de Tránsito',
        rating: 4.8,
        clientesAtendidos: Math.floor(Math.random() * 100) + 50
    };
}

// ================================================
// API: Estados de casos predefinidos
// ================================================

/**
 * Obtiene información de estados de caso
 */
async function getEstadosAPI() {
    return [
        {
            estado: 'pendiente',
            label: 'Pendiente de Revisión',
            descripcion: 'Tu caso está siendo revisado por un abogado',
            color: 'yellow',
            action: 'revision'
        },
        {
            estado: 'proceso',
            label: 'En Proceso Legal',
            descripcion: 'Se están realizando los trámites legales',
            color: 'blue',
            action: 'process'
        },
        {
            estado: 'resuelto',
            label: 'Caso Resuelto',
            descripcion: 'Tu caso ha sido resuelto',
            color: 'green',
            action: 'resolved'
        },
        {
            estado: 'rechazado',
            label: 'Rechazado',
            descripcion: 'No fue posible resolver favorablemente',
            color: 'red',
            action: 'rejected'
        }
    ];
}

// ================================================
// Utilidades de API
// ================================================

/**
 * Wrapper para fetch con manejo de errores
 */
async function safeFetch(url, options = {}) {
    try {
        const response = await fetch(url, {
            ...options,
            headers: {
                'Content-Type': 'application/json',
                ...options.headers
            }
        });
        
        if (!response.ok) {
            throw new Error(`HTTP ${response.status}: ${response.statusText}`);
        }
        
        return await response.json();
    } catch (error) {
        console.error('safeFetch error:', error);
        throw error;
    }
}

/**
 * Simula delay de red
 */
async function simulateNetworkDelay(min = 500, max = 1500) {
    const delay = Math.random() * (max - min) + min;
    return new Promise(resolve => setTimeout(resolve, delay));
}

// ================================================
// Exportar funciones para uso global
// ================================================

window.API = {
    buscarComparendoAPI,
    getUsuariosAPI,
    getPostsAPI,
    getComentariosAPI,
    testFetchAPI,
    getAbogadoStatus,
    getEstadosAPI,
    safeFetch,
    simulateNetworkDelay
};