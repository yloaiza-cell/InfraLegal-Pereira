// ================================================
// Chatbot Service - InfraLegal Pereira
// ================================================

const KNOWLEDGE_BASE = {
    multas: {
        keywords: ['multa', 'valor', 'cuánto', 'cuanto', 'precio', 'cuesta', 'monto', 'dinero'],
        category: 'información',
        responses: [
            "Los valores de las multas de tránsito en Pereira dependen del tipo de infracción:<br>• Exceso de velocidad: $468,000<br>• Estacionar en zona prohibida: $156,000<br>• No usar cinturón: $234,000<br>• Usar celular manejando: $312,000<br>• Pasar luz roja: $468,000<br><br>¿Necesitas más información sobre una infracción específica?"
        ]
    },

    plazos: {
        keywords: ['plazo', 'tiempo', 'días', 'dias', 'cuándo', 'cuando', 'vencimiento', 'vencer'],
        category: 'plazos',
        responses: [
            "Los plazos para pagar comparendos en Colombia son:<br>• Descuento del 50%: Dentro de los primeros 5 días<br>• Descuento del 25%: Entre los días 6 y 20<br>• Valor total: Después de 20 días<br><br>¿Tienes un comparendo específico que necesites pagar?"
        ]
    },

    apelacion: {
        keywords: ['apelar', 'impugnar', 'reclamar', 'recurso', 'no estoy de acuerdo', 'injusto'],
        category: 'apelación',
        responses: [
            "Para apelar un comparendo en Pereira:<br>1. Presenta escrito dentro de los 10 días hábiles<br>2. Adjunta pruebas si las tienes<br>3. Dirígete a la Oficina de Tránsito<br><br>También podemos ayudarte a preparar tu apelación. ¿Fue injusto tu comparendo?"
        ]
    },

    urgente: {
        keywords: ['urgente', 'emergencia', 'inmediato', 'ya', 'pronto', 'ahora'],
        category: 'urgente',
        responses: [
            "Entiendo que es urgente. Para casos urgentes te recomiendo:<br>1. Chatear directamente con un abogado<br>2. Llamar a la línea de atención<br>3. Realizar el pago inmediatamente si es viable<br><br>Nuestro equipo te puede atender rápidamente. ¿Me cuentas qué pasó?"
        ]
    },

    licencias: {
        keywords: ['licencia', 'suspendida', 'caducada', 'renovar', 'renovación', 'prorroga'],
        category: 'información',
        responses: [
            "Sobre licencias de conducir:<br>• Vigencia: 10 años<br>• Renovación: En cualquier oficina de tránsito<br>• Suspensión: Por acumular 20 puntos negativos<br><br>¿Necesitas información sobre cómo recuperar tu licencia?"
        ]
    },

    soat: {
        keywords: ['soat', 'seguro', 'obligatorio', 'póliza', 'cobertura'],
        category: 'información',
        responses: [
            "El SOAT es obligatorio y cubre:<br>• Gastos médicos hasta $800,000<br>• Incapacidad temporal<br>• Muerte por accidente de tránsito<br><br>Conducir sin SOAT puede resultar en multa de $624,000. ¿Tienes más preguntas?"
        ]
    },

    puntos: {
        keywords: ['puntos', 'acumulados', 'quitar', 'descargar', 'reducir'],
        category: 'información',
        responses: [
            "Sistema de puntos en Colombia:<br>• Licencia inicia con 20 puntos<br>• Pierdes puntos según la infracción<br>• Al llegar a 0, suspenden la licencia<br>• Puedes recuperar puntos con cursos presenciales<br><br>¿Quieres saber cómo recuperar tus puntos?"
        ]
    },

    ayuda: {
        keywords: ['ayuda', 'ayúdame', 'help', 'socorro', 'asistencia'],
        category: 'general',
        responses: [
            "¡Con gusto te ayudo! Puedo informarte sobre:<br>• Valores de multas<br>• Plazos para pagar<br>• Cómo apelar un comparendo<br>• Estado de tu caso legal<br><br>¿Qué necesitas saber?"
        ]
    },

    gracias: {
        keywords: ['gracias', 'thank', 'te lo agradezco', 'muy amable'],
        category: 'general',
        responses: [
            "¡De nada! Estamos para ayudarte. ¿Hay algo más en lo que pueda asistirte?"
        ]
    },

    hola: {
        keywords: ['hola', 'buenos', 'buenas', 'hello', 'hi', 'hey', 'qué tal'],
        category: 'general',
        responses: [
            "¡Hola! 👋 Bienvenido a InfraLegal Pereira.<br>Soy el asistente virtual y puedo ayudarte con:<br>• Consultar el valor de tu multa<br>• Información sobre plazos de pago<br>• Procedimientos de apelación<br>• Estado de tu caso legal<br><br>¿En qué puedo ayudarte hoy?"
        ]
    },

    bye: {
        keywords: ['adiós', 'adios', 'bye', 'hasta luego', 'chau', 'me voy'],
        category: 'general',
        responses: [
            "¡Hasta pronto! 👋 Recuerda que puedes volver cuando necesites. ¡Que tengas un buen día!"
        ]
    }
};

const DEFAULT_RESPONSES = [
    "No entendí completamente. ¿Podrías explicarme mejor qué necesitas?",
    "Puedo ayudarte con multas, plazos, apelaciones y más. ¿Cuál es tu duda específica?",
    "Para darte mejor información, necesito saber más detalles. ¿Tienes un comparendo específico?",
    "¡Interesante pregunta! Cuéntame más sobre tu situación."
];

function classifyQuery(text) {
    const lowerText = text.toLowerCase();
    let mejorMatch = null;
    let maxScore = 0;

    for (const [key, data] of Object.entries(KNOWLEDGE_BASE)) {
        let score = 0;
        for (const keyword of data.keywords) {
            if (lowerText.includes(keyword.toLowerCase())) {
                score++;
            }
        }
        if (score > maxScore) {
            maxScore = score;
            mejorMatch = {
                topic: key,
                category: data.category,
                responses: data.responses,
                score: score
            };
        }
    }

    return {
        classification: mejorMatch,
        confidence: maxScore > 0 ? maxScore / 3 : 0,
        isUrgent: lowerText.includes('urgente') || lowerText.includes('emergencia') || lowerText.includes('inmediato')
    };
}

async function generateResponse(userMessage) {
    const classification = classifyQuery(userMessage);

    // Simular delay de "pensamiento"
    await new Promise(resolve => setTimeout(resolve, 600 + Math.random() * 800));

    let responseText;
    let category = 'general';

    if (classification.classification && classification.confidence >= 0.3) {
        const topicData = classification.classification;
        responseText = topicData.responses[0]; // siempre la primera (mensaje completo)
        category = topicData.category;
    } else {
        responseText = DEFAULT_RESPONSES[Math.floor(Math.random() * DEFAULT_RESPONSES.length)];
    }

    const isUrgent = classification.isUrgent;
    if (isUrgent) category = 'urgente';

    return {
        text: responseText,
        category: category,
        isHtml: responseText.includes('<br>'),
        isUrgent: isUrgent,
        confidence: classification.confidence,
        timestamp: new Date().toISOString()
    };
}

function detectUrgency(text) {
    const urgentWords = ['urgente', 'emergencia', 'inmediato', 'ya', 'ahora', 'pronto', 'grave'];
    return urgentWords.some(word => text.toLowerCase().includes(word));
}

function detectSentiment(text) {
    const positiveWords = ['gracias', 'perfecto', 'excelente', 'genial', 'ok', 'bien'];
    const negativeWords = ['mal', 'peor', 'nada', 'no funciona', 'ayuda', 'urgente'];
    const lowerText = text.toLowerCase();
    if (positiveWords.some(w => lowerText.includes(w))) return 'positive';
    if (negativeWords.some(w => lowerText.includes(w))) return 'negative';
    return 'neutral';
}

window.CHATBOT = {
    generateResponse,
    classifyQuery,
    detectUrgency,
    detectSentiment,
    KNOWLEDGE_BASE,
    DEFAULT_RESPONSES
};
